"use strict";
exports.id = 535;
exports.ids = [535];
exports.modules = {

/***/ 30048:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Gn: () => (/* binding */ GridProSize),
/* harmony export */   QY: () => (/* binding */ GridProAlignType),
/* harmony export */   mj: () => (/* binding */ GridProFixedType)
/* harmony export */ });
var GridProSize;
(function(GridProSize) {
    GridProSize["Middle"] = "middle";
    GridProSize["Small"] = "small";
    GridProSize["Large"] = "large";
})(GridProSize || (GridProSize = {}));
var GridProAlignType;
(function(GridProAlignType) {
    GridProAlignType["Left"] = "left";
    GridProAlignType["Center"] = "center";
    GridProAlignType["Right"] = "right";
})(GridProAlignType || (GridProAlignType = {}));
var GridProFixedType;
(function(GridProFixedType) {
    GridProFixedType["Left"] = "left";
    GridProFixedType["Right"] = "right";
})(GridProFixedType || (GridProFixedType = {}));


/***/ }),

/***/ 72535:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(54359);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(58882);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _GridProType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(30048);
/**
 * <p>
 * 表格封装
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-18 13:49
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 




function toAntdColumns(columns = []) {
    return columns.map((it)=>{
        return {
            key: it.key,
            dataIndex: it.field,
            title: it.title,
            width: it.width,
            align: it.align,
            ellipsis: it.ellipsis ?? true,
            fixed: it.fixed,
            render: (text, record, index)=>{
                if (it.minWidth == void 0 || it.minWidth <= 40) return it.render?.(text, record, index) ?? text;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        minWidth: it.minWidth
                    },
                    children: it.render?.(text, record, index) ?? text
                });
            }
        };
    });
}
function GridPro(props) {
    const [columns, setColumns] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { token: { borderRadius } } = antd_lib_theme__WEBPACK_IMPORTED_MODULE_3__["default"].useToken();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setColumns(toAntdColumns(props.columns));
    }, [
        props.columns,
        props
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        props,
        style: {
            borderRadius,
            overflow: "hidden",
            ...props.style
        },
        scroll: {
            x: props.width ?? "max-content",
            y: props.height
        },
        dataSource: props.data,
        columns: columns,
        bordered: props.bordered ?? true,
        rowKey: props.rowKey,
        size: props.size ?? _GridProType__WEBPACK_IMPORTED_MODULE_2__/* .GridProSize */ .Gn.Middle
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GridPro);


/***/ })

};
;
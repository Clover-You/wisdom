exports.id = 976;
exports.ids = [976];
exports.modules = {

/***/ 53390:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24095));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43767));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76583))

/***/ }),

/***/ 43926:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(58882);
/**
 * <p>
 * 布局间距
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-14 15:43
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 

const LayoutSpace = (props)=>{
    const { direction = "horizontal" } = props;
    const { token: { padding } } = antd_lib_theme__WEBPACK_IMPORTED_MODULE_1__["default"].useToken();
    const width = direction === "horizontal" ? padding : 1, height = direction === "vertical" ? padding : 1;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            height,
            width,
            flexShrink: 0
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LayoutSpace);


/***/ }),

/***/ 29628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67953);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(58882);
/**
 * <p>
 * 页面内容盒子
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-18 13:11
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 


const MainContent = (props)=>{
    const { token: { colorBgContainer } } = antd_lib_theme__WEBPACK_IMPORTED_MODULE_1__["default"].useToken();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_card__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        ...props,
        style: {
            padding: 0,
            background: colorBgContainer,
            ...props.style
        },
        children: props.children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainContent);


/***/ }),

/***/ 24095:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Header: () => (/* binding */ Header),
  HeaderLoadingSkeleton: () => (/* binding */ HeaderLoadingSkeleton),
  "default": () => (/* binding */ layout_Header)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/layout/index.js
var layout = __webpack_require__(94608);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/space/index.js
var space = __webpack_require__(76707);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/avatar/index.js
var avatar = __webpack_require__(8608);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/card/index.js
var card = __webpack_require__(67953);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/divider/index.js
var divider = __webpack_require__(25830);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/menu/index.js
var menu = __webpack_require__(93594);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/popover/index.js
var popover = __webpack_require__(94374);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/typography/index.js
var typography = __webpack_require__(52617);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+@ant-design+icons@5.1.4_react-dom@18.2.0_react@18.2.0/node_modules/@ant-design/icons/lib/icons/LoginOutlined.js
var LoginOutlined = __webpack_require__(80573);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+next@13.4.12_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(98132);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/redux/store.ts
var store = __webpack_require__(15851);
;// CONCATENATED MODULE: ./src/layout/components/user-popover/index.tsx
/**
 * <p>
 * 用户下拉框
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-18 12:02
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 









const UserPopover = ()=>{
    const user = (0,store/* useUser */.aF)();
    const items = [
        {
            key: "1",
            label: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "#",
                children: "个人中心"
            })
        },
        {
            type: "divider",
            key: "2"
        },
        {
            key: "4",
            danger: true,
            icon: /*#__PURE__*/ jsx_runtime_.jsx(LoginOutlined["default"], {}),
            label: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/login",
                children: "安全退出"
            })
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(popover["default"], {
        align: {
            offset: [
                -80,
                -15
            ]
        },
        title: /*#__PURE__*/ jsx_runtime_.jsx(card/* default */.Z, {
            bordered: false,
            style: {
                boxShadow: "none"
            },
            size: "small",
            bodyStyle: {
                width: 260,
                overflow: "hidden",
                textOverflow: "ellipsis",
                paddingBottom: 0
            },
            headStyle: {
                background: "red"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(card/* default */.Z.Meta, {
                avatar: /*#__PURE__*/ jsx_runtime_.jsx(avatar/* default */.ZP, {
                    src: user.user?.avatar,
                    size: "large"
                }),
                title: user.user?.userName ?? "旺财",
                description: /*#__PURE__*/ jsx_runtime_.jsx(typography/* default */.Z.Text, {
                    ellipsis: true,
                    type: "secondary",
                    style: {
                        fontWeight: 500,
                        transform: "translateY(-8px)"
                    },
                    children: "问君能有几多愁 恰似一江春水向东流"
                })
            })
        }),
        trigger: "click",
        style: {
            marginTop: 10
        },
        content: [
            /*#__PURE__*/ jsx_runtime_.jsx(divider/* default */.Z, {
                style: {
                    margin: 0,
                    marginBottom: 8
                }
            }, 1),
            /*#__PURE__*/ jsx_runtime_.jsx(menu["default"], {
                style: {
                    width: 260,
                    border: "none",
                    borderRadius: 6
                },
                items: items,
                selectable: false
            }, 2)
        ],
        children: /*#__PURE__*/ jsx_runtime_.jsx(avatar/* default */.ZP, {
            size: "small",
            src: "https://thirdqq.qlogo.cn/g?b=sdk&k=dAic2iagp1UicyseX6aIHmicDA&kti=ZK9mhwAAAAE&s=100&t=1688390589"
        })
    });
};
/* harmony default export */ const user_popover = (UserPopover);

// EXTERNAL MODULE: ./src/components/MainContent.tsx
var MainContent = __webpack_require__(29628);
;// CONCATENATED MODULE: ./src/layout/Header.tsx
/**
 * <p>
 * 头部布局
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-13 10:42
 */ /* __next_internal_client_entry_do_not_use__ Header,HeaderLoadingSkeleton,default auto */ 




const Header = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(MainContent["default"], {
            bodyStyle: {
                padding: 0
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z.Header, {
                style: {
                    background: "none",
                    display: "flex",
                    height: 48,
                    alignItems: "center",
                    justifyContent: "space-between",
                    ...props.style
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: "LOGO"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(space["default"], {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(user_popover, {})
                    })
                ]
            })
        })
    });
};
const HeaderLoadingSkeleton = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: "加载中"
    });
};
/* harmony default export */ const layout_Header = (Header);


/***/ }),

/***/ 43767:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_LayoutSpace__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43926);
/* harmony import */ var antd_lib_layout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(94608);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58882);
/* harmony import */ var antd_lib_watermark__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22401);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(15851);
/**
 * <p>
 * a1
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-14 15:32
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 






const RootLayout = (props)=>{
    const user = (0,_redux_store__WEBPACK_IMPORTED_MODULE_3__/* .useUser */ .aF)();
    const { token: { padding, borderRadius } } = antd_lib_theme__WEBPACK_IMPORTED_MODULE_4__["default"].useToken();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_watermark__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        content: [
            user.user?.userName ?? "",
            user.user?.phone ?? ""
        ],
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_layout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            style: {
                minHeight: "100vh",
                maxHeight: "100vh",
                padding: padding
            },
            children: [
                props.header,
                props.header == void 0 ? undefined : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_LayoutSpace__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    direction: "vertical"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_layout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    style: {
                        flexGrow: 1,
                        flexDirection: "initial"
                    },
                    children: [
                        props.sider,
                        props.sider == void 0 ? undefined : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_LayoutSpace__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            direction: "horizontal"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_layout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            style: {
                                overflow: "hidden"
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_layout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z.Content, {
                                style: {
                                    minHeight: 280,
                                    overflowY: "auto",
                                    borderRadius: borderRadius
                                },
                                children: [
                                    props.content,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_layout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z.Footer, {
                                        children: props.footer
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RootLayout);


/***/ }),

/***/ 76583:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout_SiderCard)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/components/MainContent.tsx
var MainContent = __webpack_require__(29628);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+@ant-design+icons@5.1.4_react-dom@18.2.0_react@18.2.0/node_modules/@ant-design/icons/lib/icons/ContainerOutlined.js
var ContainerOutlined = __webpack_require__(65370);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/menu/index.js
var menu = __webpack_require__(93594);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+classnames@2.3.2/node_modules/classnames/index.js
var classnames = __webpack_require__(48746);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+next@13.4.12_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(98132);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/es/theme/util/genComponentStyleHook.js + 20 modules
var genComponentStyleHook = __webpack_require__(89622);
;// CONCATENATED MODULE: ./src/layout/components/sider-menu/style/index.ts
/**
 * <p>
 * 菜单栏样式
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-14 13:43
 */ 
const genCustomMenuStyle = (token)=>{
    const { componentCls } = token;
    return [
        {
            [componentCls]: {
                [".ant-menu.ant-menu-sub.ant-menu-inline"]: {
                    background: "none"
                }
            }
        }
    ];
};
/* harmony default export */ const style = ((0,genComponentStyleHook/* default */.Z)("Menu", (token)=>{
    return [
        genCustomMenuStyle(token)
    ];
}));

;// CONCATENATED MODULE: ./src/layout/components/sider-menu/index.tsx
/**
 * <p>
 * 侧边栏菜单
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-14 13:40
 */ 






const items2 = [
    {
        icon: /*#__PURE__*/ react_default().createElement(ContainerOutlined["default"]),
        label: "资料",
        key: "Setting",
        children: [
            {
                label: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/unit/list",
                    children: "单位设置"
                }),
                key: "UnitSetting"
            },
            {
                label: "商品",
                key: "SettingProduct",
                children: [
                    {
                        label: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/product/list",
                            children: "商品资料"
                        }),
                        key: "ProductList"
                    },
                    {
                        label: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/product/class-setting",
                            children: "商品分类"
                        }),
                        key: "ClassSetting"
                    }
                ]
            }
        ]
    }
];
const SiderMenu = ()=>{
    const prefixCls = "wisdom-menu";
    const [wrapSSR, hashId] = style(prefixCls);
    return wrapSSR(/*#__PURE__*/ jsx_runtime_.jsx(menu["default"], {
        className: classnames_default()(prefixCls, hashId),
        mode: "inline",
        defaultSelectedKeys: [
            "1"
        ],
        defaultOpenKeys: [
            "sub1"
        ],
        style: {
            height: "100%",
            borderRight: 6
        },
        items: items2
    }));
};
/* harmony default export */ const sider_menu = (SiderMenu);

;// CONCATENATED MODULE: ./src/layout/SiderCard.tsx
/**
 * <p>
 * a1
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-14 15:58
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 


const SiderCard = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(MainContent["default"], {
        style: {
            overflow: "auto",
            width: 260,
            flexShrink: 0
        },
        size: "small",
        children: /*#__PURE__*/ jsx_runtime_.jsx(sider_menu, {})
    });
};
/* harmony default export */ const layout_SiderCard = (SiderCard);


/***/ }),

/***/ 55991:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout_RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+next@13.4.12_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(44266);
;// CONCATENATED MODULE: ./src/layout/Header.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/layout/Header.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Header"];

const e1 = proxy["HeaderLoadingSkeleton"];


/* harmony default export */ const Header = (__default__);
;// CONCATENATED MODULE: ./src/layout/RootLayout.tsx

const RootLayout_proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/layout/RootLayout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: RootLayout_esModule, $$typeof: RootLayout_$$typeof } = RootLayout_proxy;
const RootLayout_default_ = RootLayout_proxy.default;


/* harmony default export */ const RootLayout = (RootLayout_default_);
;// CONCATENATED MODULE: ./src/layout/SiderCard.tsx

const SiderCard_proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/layout/SiderCard.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: SiderCard_esModule, $$typeof: SiderCard_$$typeof } = SiderCard_proxy;
const SiderCard_default_ = SiderCard_proxy.default;


/* harmony default export */ const SiderCard = (SiderCard_default_);
;// CONCATENATED MODULE: ./src/layout/BaseLayout.tsx
/**
 * <p>
 * 基础布局
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-13 10:24
 */ 



const BaseLayout = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(RootLayout, {
            header: /*#__PURE__*/ jsx_runtime_.jsx(Header, {
                style: {
                    height: 48
                }
            }),
            sider: /*#__PURE__*/ jsx_runtime_.jsx(SiderCard, {}),
            content: props.children,
            footer: "Wisdom mall \xa92023 Created by Clover You"
        })
    });
};
/* harmony default export */ const layout_BaseLayout = (BaseLayout);

;// CONCATENATED MODULE: ./src/app/(BaseLayout)/layout.tsx
// import { Inter } from 'next/font/google'


// const inter = Inter({ subsets: ['latin'] })
const metadata = {
    title: "Wisdom mall",
    description: "Generated by create next app"
};
function layout_RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(layout_BaseLayout, {
        children: children
    });
}


/***/ })

};
;
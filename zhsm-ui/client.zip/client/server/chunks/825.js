"use strict";
exports.id = 825;
exports.ids = [825];
exports.modules = {

/***/ 78898:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



var _interopRequireWildcard = (__webpack_require__(54586)["default"]);
var _interopRequireDefault = (__webpack_require__(76615)["default"]);
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _classnames = _interopRequireDefault(__webpack_require__(48746));
var _rcCheckbox = _interopRequireDefault(__webpack_require__(14378));
var React = _interopRequireWildcard(__webpack_require__(18038));
var _warning = _interopRequireDefault(__webpack_require__(93583));
var _configProvider = __webpack_require__(5873);
var _DisabledContext = _interopRequireDefault(__webpack_require__(27257));
var _context = __webpack_require__(46994);
var _GroupContext = _interopRequireDefault(__webpack_require__(91304));
var _style = _interopRequireDefault(__webpack_require__(59275));
var __rest = void 0 && (void 0).__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
const InternalCheckbox = (props, ref) => {
  var _a;
  const {
      prefixCls: customizePrefixCls,
      className,
      rootClassName,
      children,
      indeterminate = false,
      style,
      onMouseEnter,
      onMouseLeave,
      skipGroup = false,
      disabled
    } = props,
    restProps = __rest(props, ["prefixCls", "className", "rootClassName", "children", "indeterminate", "style", "onMouseEnter", "onMouseLeave", "skipGroup", "disabled"]);
  const {
    getPrefixCls,
    direction,
    checkbox
  } = React.useContext(_configProvider.ConfigContext);
  const checkboxGroup = React.useContext(_GroupContext.default);
  const {
    isFormItemInput
  } = React.useContext(_context.FormItemInputContext);
  const contextDisabled = React.useContext(_DisabledContext.default);
  const mergedDisabled = (_a = (checkboxGroup === null || checkboxGroup === void 0 ? void 0 : checkboxGroup.disabled) || disabled) !== null && _a !== void 0 ? _a : contextDisabled;
  const prevValue = React.useRef(restProps.value);
  React.useEffect(() => {
    checkboxGroup === null || checkboxGroup === void 0 ? void 0 : checkboxGroup.registerValue(restProps.value);
     false ? 0 : void 0;
  }, []);
  React.useEffect(() => {
    if (skipGroup) {
      return;
    }
    if (restProps.value !== prevValue.current) {
      checkboxGroup === null || checkboxGroup === void 0 ? void 0 : checkboxGroup.cancelValue(prevValue.current);
      checkboxGroup === null || checkboxGroup === void 0 ? void 0 : checkboxGroup.registerValue(restProps.value);
      prevValue.current = restProps.value;
    }
    return () => checkboxGroup === null || checkboxGroup === void 0 ? void 0 : checkboxGroup.cancelValue(restProps.value);
  }, [restProps.value]);
  const prefixCls = getPrefixCls('checkbox', customizePrefixCls);
  const [wrapSSR, hashId] = (0, _style.default)(prefixCls);
  const checkboxProps = Object.assign({}, restProps);
  if (checkboxGroup && !skipGroup) {
    checkboxProps.onChange = function () {
      if (restProps.onChange) {
        restProps.onChange.apply(restProps, arguments);
      }
      if (checkboxGroup.toggleOption) {
        checkboxGroup.toggleOption({
          label: children,
          value: restProps.value
        });
      }
    };
    checkboxProps.name = checkboxGroup.name;
    checkboxProps.checked = checkboxGroup.value.includes(restProps.value);
  }
  const classString = (0, _classnames.default)(`${prefixCls}-wrapper`, {
    [`${prefixCls}-rtl`]: direction === 'rtl',
    [`${prefixCls}-wrapper-checked`]: checkboxProps.checked,
    [`${prefixCls}-wrapper-disabled`]: mergedDisabled,
    [`${prefixCls}-wrapper-in-form-item`]: isFormItemInput
  }, checkbox === null || checkbox === void 0 ? void 0 : checkbox.className, className, rootClassName, hashId);
  const checkboxClass = (0, _classnames.default)({
    [`${prefixCls}-indeterminate`]: indeterminate
  }, hashId);
  const ariaChecked = indeterminate ? 'mixed' : undefined;
  return wrapSSR(
  /*#__PURE__*/
  // eslint-disable-next-line jsx-a11y/label-has-associated-control
  React.createElement("label", {
    className: classString,
    style: Object.assign(Object.assign({}, checkbox === null || checkbox === void 0 ? void 0 : checkbox.style), style),
    onMouseEnter: onMouseEnter,
    onMouseLeave: onMouseLeave
  }, /*#__PURE__*/React.createElement(_rcCheckbox.default, Object.assign({
    "aria-checked": ariaChecked
  }, checkboxProps, {
    prefixCls: prefixCls,
    className: checkboxClass,
    disabled: mergedDisabled,
    ref: ref
  })), children !== undefined && /*#__PURE__*/React.createElement("span", null, children)));
};
const Checkbox = /*#__PURE__*/React.forwardRef(InternalCheckbox);
if (false) {}
var _default = Checkbox;
exports["default"] = _default;

/***/ }),

/***/ 71531:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



var _interopRequireWildcard = (__webpack_require__(54586)["default"]);
var _interopRequireDefault = (__webpack_require__(76615)["default"]);
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "GroupContext", ({
  enumerable: true,
  get: function () {
    return _GroupContext.default;
  }
}));
exports["default"] = void 0;
var _toConsumableArray2 = _interopRequireDefault(__webpack_require__(18511));
var _classnames = _interopRequireDefault(__webpack_require__(48746));
var _omit = _interopRequireDefault(__webpack_require__(38881));
var React = _interopRequireWildcard(__webpack_require__(18038));
var _configProvider = __webpack_require__(5873);
var _Checkbox = _interopRequireDefault(__webpack_require__(78898));
var _GroupContext = _interopRequireDefault(__webpack_require__(91304));
var _style = _interopRequireDefault(__webpack_require__(59275));
var __rest = void 0 && (void 0).__rest || function (s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
};
const InternalGroup = (props, ref) => {
  const {
      defaultValue,
      children,
      options = [],
      prefixCls: customizePrefixCls,
      className,
      rootClassName,
      style,
      onChange
    } = props,
    restProps = __rest(props, ["defaultValue", "children", "options", "prefixCls", "className", "rootClassName", "style", "onChange"]);
  const {
    getPrefixCls,
    direction
  } = React.useContext(_configProvider.ConfigContext);
  const [value, setValue] = React.useState(restProps.value || defaultValue || []);
  const [registeredValues, setRegisteredValues] = React.useState([]);
  React.useEffect(() => {
    if ('value' in restProps) {
      setValue(restProps.value || []);
    }
  }, [restProps.value]);
  const memoOptions = React.useMemo(() => options.map(option => {
    if (typeof option === 'string' || typeof option === 'number') {
      return {
        label: option,
        value: option
      };
    }
    return option;
  }), [options]);
  const cancelValue = val => {
    setRegisteredValues(prevValues => prevValues.filter(v => v !== val));
  };
  const registerValue = val => {
    setRegisteredValues(prevValues => [].concat((0, _toConsumableArray2.default)(prevValues), [val]));
  };
  const toggleOption = option => {
    const optionIndex = value.indexOf(option.value);
    const newValue = (0, _toConsumableArray2.default)(value);
    if (optionIndex === -1) {
      newValue.push(option.value);
    } else {
      newValue.splice(optionIndex, 1);
    }
    if (!('value' in restProps)) {
      setValue(newValue);
    }
    onChange === null || onChange === void 0 ? void 0 : onChange(newValue.filter(val => registeredValues.includes(val)).sort((a, b) => {
      const indexA = memoOptions.findIndex(opt => opt.value === a);
      const indexB = memoOptions.findIndex(opt => opt.value === b);
      return indexA - indexB;
    }));
  };
  const prefixCls = getPrefixCls('checkbox', customizePrefixCls);
  const groupPrefixCls = `${prefixCls}-group`;
  const [wrapSSR, hashId] = (0, _style.default)(prefixCls);
  const domProps = (0, _omit.default)(restProps, ['value', 'disabled']);
  const childrenNode = options.length ? memoOptions.map(option => /*#__PURE__*/React.createElement(_Checkbox.default, {
    prefixCls: prefixCls,
    key: option.value.toString(),
    disabled: 'disabled' in option ? option.disabled : restProps.disabled,
    value: option.value,
    checked: value.includes(option.value),
    onChange: option.onChange,
    className: `${groupPrefixCls}-item`,
    style: option.style,
    title: option.title
  }, option.label)) : children;
  // eslint-disable-next-line react/jsx-no-constructed-context-values
  const context = {
    toggleOption,
    value,
    disabled: restProps.disabled,
    name: restProps.name,
    // https://github.com/ant-design/ant-design/issues/16376
    registerValue,
    cancelValue
  };
  const classString = (0, _classnames.default)(groupPrefixCls, {
    [`${groupPrefixCls}-rtl`]: direction === 'rtl'
  }, className, rootClassName, hashId);
  return wrapSSR( /*#__PURE__*/React.createElement("div", Object.assign({
    className: classString,
    style: style
  }, domProps, {
    ref: ref
  }), /*#__PURE__*/React.createElement(_GroupContext.default.Provider, {
    value: context
  }, childrenNode)));
};
const CheckboxGroup = /*#__PURE__*/React.forwardRef(InternalGroup);
var _default = /*#__PURE__*/React.memo(CheckboxGroup);
exports["default"] = _default;

/***/ }),

/***/ 91304:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



var _interopRequireDefault = (__webpack_require__(76615)["default"]);
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(18038));
const GroupContext = /*#__PURE__*/_react.default.createContext(null);
var _default = GroupContext;
exports["default"] = _default;

/***/ }),

/***/ 41825:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


'use client';

var _interopRequireDefault = (__webpack_require__(76615)["default"]);
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _Checkbox = _interopRequireDefault(__webpack_require__(78898));
var _Group = _interopRequireDefault(__webpack_require__(71531));
const Checkbox = _Checkbox.default;
Checkbox.Group = _Group.default;
Checkbox.__ANT_CHECKBOX = true;
if (false) {}
var _default = Checkbox;
exports["default"] = _default;

/***/ })

};
;
exports.id = 710;
exports.ids = [710];
exports.modules = {

/***/ 63044:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 77013, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 56010, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 49238, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 44367, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 81215, 23))

/***/ }),

/***/ 17564:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 35064));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86902))

/***/ }),

/***/ 62711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G: () => (/* binding */ userLoginByMobile),
/* harmony export */   e: () => (/* binding */ sendLoginPhoneVerifyCode)
/* harmony export */ });
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(81259);
/* harmony import */ var _constant_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71928);
/**
 * <p>
 * 登录接口
 * </p>
 * @author Clover
 * @date 2023-07-07 23:32
 */ 

/**
 * 发送登录验证码
 * @param phone 手机号
 */ const sendLoginPhoneVerifyCode = (phone)=>{
    return _utils_request__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.get(_constant_service__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.login.send_login_verify_code, {
        params: {
            phone
        }
    });
};
/**
 * 手机验证码登录
 * @param params 登录参数
 * @returns 
 */ const userLoginByMobile = (params)=>{
    return _utils_request__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.post(_constant_service__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.login.user_login, params);
};


/***/ }),

/***/ 35064:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AntdProvider: () => (/* binding */ AntdProvider),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_app__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(63016);
/* harmony import */ var antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5873);
/* harmony import */ var antd_lib_notification__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53482);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(58882);
/* harmony import */ var _ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(81831);
/* harmony import */ var _hooks_antd_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(29365);
/* harmony import */ var antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(33506);
/**
 * <p>
 * 收集所有 css
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-13 09:46
 */ /* __next_internal_client_entry_do_not_use__ AntdProvider,default auto */ 







const AntdProvider = ({ children })=>{
    const [notificationApi, notificationContext] = antd_lib_notification__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP.useNotification();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_1__.StyleProvider, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_4__["default"], {
                locale: antd_locale_zh_CN__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                theme: {
                    algorithm: antd_lib_theme__WEBPACK_IMPORTED_MODULE_6__["default"].darkAlgorithm
                },
                children: [
                    notificationContext,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_hooks_antd_context__WEBPACK_IMPORTED_MODULE_2__/* .AntdContextProvider */ .Z$, {
                        value: {
                            notificationApi
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_app__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            children: children
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AntdProvider);


/***/ }),

/***/ 71928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ constant_service)
});

;// CONCATENATED MODULE: ./src/constant/service/login.ts
/**
 * <p>
 * 登录接口
 * </p>
 * @author Clover
 * @date 2023-07-08 01:37
 */ const login = {
    // 发送登录验证码
    send_login_verify_code: "/api/third-party/mobile-phone-verify-code/send-login-code",
    // 手机验证码登录
    user_login: "/api/user/auth/mobile-phone-login"
};

;// CONCATENATED MODULE: ./src/constant/service/user.ts
/**
 * <p>
 * 用户控制器接口
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-13 11:26
 */ const user = {
    // 获取用户信息
    fetch_user_info: "/api/user/user-info"
};

;// CONCATENATED MODULE: ./src/constant/service/index.ts
/**
 * <p>
 * api 服务地址
 * </p>
 * @author Clover
 * @date 2023-07-08 01:36
 */ 

const service = {
    login: login,
    user: user
};
/* harmony default export */ const constant_service = (service);


/***/ }),

/***/ 29365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Mg: () => (/* binding */ AntdContext),
/* harmony export */   Z$: () => (/* binding */ AntdContextProvider)
/* harmony export */ });
/* unused harmony export DefaultAntdContext */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/**
 * <p>
 * antd 组件相关的 context
 * </p>
 * @author Clover
 * @date 2023-07-24 09:41
 */ 
const DefaultAntdContext = {
    notificationApi: undefined
};
const context = react__WEBPACK_IMPORTED_MODULE_0___default().createContext(DefaultAntdContext);
const AntdContextProvider = context.Provider;
const AntdContext = context;


/***/ }),

/***/ 86902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReduxProvider: () => (/* binding */ ReduxProvider),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74155);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15851);
/**
 * <p>
 * Redux 上下文提供
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-12 20:31
 */ /* __next_internal_client_entry_do_not_use__ ReduxProvider,default auto */ 


const ReduxProvider = ({ children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, {
        store: _store__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReduxProvider);


/***/ }),

/***/ 15851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I0: () => (/* binding */ useDispatch),
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   aF: () => (/* binding */ useUser)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(67718);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9391);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _user__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(70308);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(74155);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/**
 * <p>
 * 创建 redux
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-12 18:13
 */ 



const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_3__.configureStore)({
    middleware: (getDefaultMiddleware)=>{
        return getDefaultMiddleware({
            serializableCheck: false
        });
    },
    reducer: {
        user: _user__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP
    }
});
const useUser = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.user);
(0,redux_persist__WEBPACK_IMPORTED_MODULE_0__.persistStore)(store);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store);
const useDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();


/***/ }),

/***/ 70308:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  CC: () => (/* binding */ GetUserInfo),
  xF: () => (/* binding */ LoginByMobile),
  ZP: () => (/* binding */ user)
});

// UNUSED EXPORTS: SetName

// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+redux-persist@6.0.0_react@18.2.0_redux@4.2.1/node_modules/redux-persist/lib/index.js
var lib = __webpack_require__(9391);
// EXTERNAL MODULE: ./src/api/login.ts
var login = __webpack_require__(62711);
// EXTERNAL MODULE: ./src/utils/request/index.ts
var request = __webpack_require__(81259);
// EXTERNAL MODULE: ./src/constant/service/index.ts + 2 modules
var service = __webpack_require__(71928);
;// CONCATENATED MODULE: ./src/api/user.ts
/**
 * <p>
 * 用户接口
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-13 11:25
 */ 

/**
 * 获取用户信息
 */ const fetchUserInfo = ()=>{
    return request/* default */.Z.get(service/* default */.Z.user.fetch_user_info);
};

// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+@reduxjs+toolkit@1.9.5_react-redux@8.1.1_react@18.2.0/node_modules/@reduxjs/toolkit/dist/redux-toolkit.cjs.production.min.js
var redux_toolkit_cjs_production_min = __webpack_require__(67718);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+redux-persist@6.0.0_react@18.2.0_redux@4.2.1/node_modules/redux-persist/es/storage/session.js + 2 modules
var session = __webpack_require__(26280);
;// CONCATENATED MODULE: ./src/redux/user.ts
/**
 * <p>
 * 用户信息
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-12 18:15
 */ 




const initialState = {
    user: undefined,
    loginState: false,
    token: undefined,
    name: ""
};
const userStore = (0,redux_toolkit_cjs_production_min.createSlice)({
    name: "USER_STORE",
    initialState,
    reducers: {
        UserLoginByMobile (state, { payload }) {
            const params = payload;
            return {
                ...state,
                loginState: true,
                user: payload
            };
        },
        SetName (state, { payload }) {
            state.name = payload;
        }
    },
    extraReducers (builder) {
        // 异步请求登录时触发
        builder.addCase(LoginByMobile.fulfilled, (state, { payload })=>{
            // 如果业务状态码不是200，那么不做操作交由UI处理
            if (payload.data.code != 200) return;
            state.loginState = true;
            state.token = payload.data?.data;
            state.name = Date.now() + "";
        });
        builder.addCase(GetUserInfo.fulfilled, (state, { payload })=>{
            if (payload.data.code != 200) return;
            state.user = payload.data?.data;
        });
    }
});
const { SetName } = userStore.actions;
/* harmony default export */ const user = ((0,lib.persistReducer)({
    storage: session/* default */.Z,
    key: "USER_STORE_STORAGE"
}, userStore.reducer));
const LoginByMobile = (0,redux_toolkit_cjs_production_min.createAsyncThunk)("USER_STORE/LoginByMobile", async (params, { rejectWithValue })=>{
    try {
        const result = await (0,login/* userLoginByMobile */.G)(params);
        return result;
    } catch (err) {
        return rejectWithValue(err);
    }
});
const GetUserInfo = (0,redux_toolkit_cjs_production_min.createAsyncThunk)("USER_STORE/GetUserInfo", async (arg, { rejectWithValue })=>{
    try {
        const result = await fetchUserInfo();
        return result;
    } catch (err) {
        return rejectWithValue(err);
    }
});


/***/ }),

/***/ 81259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(36149);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15851);
/**
 * <p>
 * axios 二次封装
 * </p>
 * @author Clover
 * @date 2023-07-08 01:29
 */ 

const http = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({});
http.interceptors.request.use(async (config)=>{
    const user = _redux_store__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP.getState().user;
    user.token != void 0 && (config.headers.Authorization = `Bearer ${user.token}`);
    return config;
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (http);


/***/ }),

/***/ 85597:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+next@13.4.12_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(44266);
;// CONCATENATED MODULE: ./src/redux/provider.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/redux/provider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["ReduxProvider"];


/* harmony default export */ const provider = ((/* unused pure expression or super */ null && (__default__)));
;// CONCATENATED MODULE: ./src/app/AntdProvider.tsx

const AntdProvider_proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/app/AntdProvider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: AntdProvider_esModule, $$typeof: AntdProvider_$$typeof } = AntdProvider_proxy;
const AntdProvider_default_ = AntdProvider_proxy.default;

const AntdProvider_e0 = AntdProvider_proxy["AntdProvider"];


/* harmony default export */ const AntdProvider = ((/* unused pure expression or super */ null && (AntdProvider_default_)));
;// CONCATENATED MODULE: ./src/app/layout.tsx


// import { Inter } from 'next/font/google'

// const inter = Inter({ subsets: ['latin'] })
const metadata = {
    title: "Create Next App",
    description: "Generated by create next app"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ jsx_runtime_.jsx("body", {
            style: {
                margin: 0
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(e0, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(AntdProvider_e0, {
                    children: children
                })
            })
        })
    });
}


/***/ }),

/***/ 12356:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(68372);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ })

};
;
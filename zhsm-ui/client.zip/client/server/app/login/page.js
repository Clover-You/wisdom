(() => {
var exports = {};
exports.id = 626;
exports.ids = [626];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 16826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25980);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10119);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59692);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'login',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38927)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/login/page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12356))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85597)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12356))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/clover/dev-project/zhsm/zhsm-ui/src/app/login/page.tsx"];

    

    const originalPathname = "/login/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/login/page","pathname":"/login","bundlePath":"app/login/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 67189:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40112));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2982, 23))

/***/ }),

/***/ 40112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ login_LoginCard)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+@ant-design+icons@5.1.4_react-dom@18.2.0_react@18.2.0/node_modules/@ant-design/icons/lib/icons/LockOutlined.js
var LockOutlined = __webpack_require__(180);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+@ant-design+icons@5.1.4_react-dom@18.2.0_react@18.2.0/node_modules/@ant-design/icons/lib/icons/UserOutlined.js
var UserOutlined = __webpack_require__(97845);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/button/index.js
var lib_button = __webpack_require__(14680);
var button_default = /*#__PURE__*/__webpack_require__.n(lib_button);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/card/index.js
var card = __webpack_require__(67953);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/checkbox/index.js
var lib_checkbox = __webpack_require__(41825);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/col/index.js
var col = __webpack_require__(9833);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/config-provider/index.js
var config_provider = __webpack_require__(5873);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/form/index.js
var lib_form = __webpack_require__(51690);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/input/index.js
var input = __webpack_require__(51413);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/message/index.js
var message = __webpack_require__(83131);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/row/index.js
var row = __webpack_require__(25934);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/space/index.js
var space = __webpack_require__(76707);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/theme/index.js
var theme = __webpack_require__(58882);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+next@13.4.12_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(98132);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./src/redux/store.ts
var store = __webpack_require__(15851);
// EXTERNAL MODULE: ./src/redux/user.ts + 1 modules
var redux_user = __webpack_require__(70308);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/index.js
var axios = __webpack_require__(44169);
// EXTERNAL MODULE: ./src/api/login.ts
var login = __webpack_require__(62711);
;// CONCATENATED MODULE: ./src/app/login/SendPhoneCodeButton.tsx
/**
 * <p>
 * 发送登录验证码按钮
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-12 16:40
 */ 




const SendPhoneCodeButton = (props)=>{
    const [disableState, setDisable] = (0,react_.useState)(false);
    const [loadState, setLoad] = (0,react_.useState)(false);
    const [timing, setCountdown] = (0,react_.useState)(60);
    /**
   * 发送登录验证码
   */ const sendLoginVerifyCode = async ()=>{
        if (!await props.before()) return;
        try {
            setLoad(true);
            // 发送验证码
            const phone = await props.getPhone();
            const resp = await (0,login/* sendLoginPhoneVerifyCode */.e)(phone);
            // 处理响应状态
            const { code, message: codeMessage } = resp.data;
            if (code != 200) return message/* default */.ZP.error(codeMessage);
            // 登录验证码发送成功，开启倒计时
            startCountdown();
        } catch (e) {
            console.error(e);
            message/* default */.ZP.error(`验证码发送失败，系统异常\,${e}`);
        } finally{
            setLoad(false);
        }
    };
    const timer = (0,react_.useRef)(undefined);
    /**
   * 开启计时
   */ const startCountdown = async ()=>{
        if (disableState) return;
        setDisable(true);
        timer.current = setInterval(()=>{
            setCountdown((timing)=>{
                if (timing == 0) {
                    timer.current != void 0 && clearInterval(timer.current);
                    timer.current = undefined;
                    setDisable(false);
                    return 60;
                }
                return timing - 1;
            });
        }, 1000);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
            style: props.style,
            onClick: sendLoginVerifyCode,
            loading: loadState,
            disabled: disableState,
            children: disableState ? timing : "发送验证码"
        })
    });
};

// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+next@13.4.12_react-dom@18.2.0_react@18.2.0/node_modules/next/navigation.js
var navigation = __webpack_require__(20189);
// EXTERNAL MODULE: ./src/hooks/antd/context.ts
var context = __webpack_require__(29365);
;// CONCATENATED MODULE: ./src/hooks/antd/useNotification.ts
/**
 * <p>
 * antd 通知
 * </p>
 * @author Clover
 * @date 2023-07-24 09:38
 */ 

const useNotification = ()=>{
    const { notificationApi } = (0,react_.useContext)(context/* AntdContext */.Mg);
    return notificationApi;
};

;// CONCATENATED MODULE: ./src/app/login/LoginCard.tsx
/**
 * <p>
 * 登录卡片
 * </p>
 * @author Clover
 * @date 2023-06-30 17:52
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 





















const LoginCard = ()=>{
    const { token } = theme["default"].useToken();
    const router = (0,navigation.useRouter)();
    const [form] = lib_form/* default */.Z.useForm();
    const [messageApi, messageContextHolder] = message/* default */.ZP.useMessage();
    const [loadState, setLoad] = (0,react_.useState)(false);
    const dispatch = (0,store/* useDispatch */.I0)();
    const notificationApi = useNotification();
    const onLoginFinish = async (params)=>{
        try {
            setLoad(true);
            const response = await dispatch((0,redux_user/* LoginByMobile */.xF)(params));
            if (response.payload instanceof axios/* AxiosError */.d7) throw response.payload;
            const { data: { code, message } } = response.payload;
            if (code != 200) return messageApi.error(message);
            // 记录用户登录状态与用户基础信息
            const userInfoResponse = await dispatch((0,redux_user/* GetUserInfo */.CC)());
            if (userInfoResponse.payload instanceof axios/* AxiosError */.d7) throw userInfoResponse.payload;
            const { data: { code: userInfoResponseCode, message: userInfoResponseMessage } } = userInfoResponse.payload;
            if (userInfoResponseCode != 200) return messageApi.error(userInfoResponseMessage);
            await router.replace("/home");
            const user = store/* default */.ZP.getState().user;
            // 一秒后显示欢迎回来，不能使用 hook，因为上下文一秒后将消失
            setTimeout(()=>{
                notificationApi?.open({
                    message: "\uD83C\uDF89 欢迎",
                    description: `${user.user?.userName}!下午好,欢迎回来👏`
                });
            }, 3000);
        } catch (err) {
            // 检查是否 AxiosError 异常并且状态码是 403
            if (err instanceof axios/* AxiosError */.d7) {
                if (err.response?.status === 403) {
                    return messageApi.error("登录失败");
                }
            }
            console.error(err);
            messageApi.error(`系统异常\n${err}`);
        } finally{
            setLoad(false);
        }
    };
    /**
   * 执行数据校验
   */ const validateFields = (err)=>{
        if (err?.errorFields == void 0 || (err?.errorFields?.length ?? 0) === 0) return;
        const { errorFields: [{ errors: [errorMessage] }] } = err;
        messageApi.error(errorMessage);
    };
    /**
   * 校验手机号
   */ const verifyPhoneCode = async ()=>{
        try {
            await form.validateFields([
                "phone"
            ]);
            return true;
        } catch (e) {
            const errorCount = e.errorFields?.length ?? 0;
            if (errorCount === 0) return false;
            const errorMessage = e.errorFields[0].errors?.[0] ?? "";
            messageApi.error(errorMessage);
        }
        return false;
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            messageContextHolder,
            /*#__PURE__*/ jsx_runtime_.jsx(config_provider["default"], {
                componentSize: "large",
                children: /*#__PURE__*/ jsx_runtime_.jsx(card/* default */.Z, {
                    title: "登录",
                    style: {
                        width: 500,
                        transform: "translate(-50%, -50%)",
                        top: "50%",
                        left: "50%",
                        boxShadow: token.boxShadowSecondary
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib_form/* default */.Z, {
                        scrollToFirstError: true,
                        labelCol: {
                            span: 2
                        },
                        autoComplete: "off",
                        form: form,
                        onFinish: onLoginFinish,
                        onFinishFailed: validateFields,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(space["default"], {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "还没有账号?"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/register",
                                            children: "去注册"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                                name: "phone",
                                help: "",
                                rules: [
                                    {
                                        required: true,
                                        message: "请输入登录手机号"
                                    }
                                ],
                                children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                    prefix: /*#__PURE__*/ jsx_runtime_.jsx(UserOutlined["default"], {
                                        style: {
                                            color: token.colorTextPlaceholder
                                        }
                                    }),
                                    placeholder: "手机号"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                                name: "verifyCode",
                                help: "",
                                rules: [
                                    {
                                        required: true,
                                        message: "请输入6位验证码!"
                                    }
                                ],
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(space["default"].Compact, {
                                    style: {
                                        width: "100%"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                            prefix: /*#__PURE__*/ jsx_runtime_.jsx(LockOutlined["default"], {
                                                style: {
                                                    color: token.colorTextPlaceholder
                                                }
                                            }),
                                            autoComplete: "none",
                                            placeholder: "验证码"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(SendPhoneCodeButton, {
                                            style: {
                                                minWidth: 110
                                            },
                                            before: verifyPhoneCode,
                                            getPhone: async ()=>form.getFieldValue("phone")
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(row/* default */.Z, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                                            flex: 1,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(lib_checkbox["default"], {
                                                children: "记住我"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/forget",
                                                children: "忘记密码?"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                                block: true,
                                htmlType: "submit",
                                type: "primary",
                                loading: loadState,
                                children: "登录"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const login_LoginCard = (LoginCard);


/***/ }),

/***/ 38927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(67703);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/**
 * <p>
 * 登录页面
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-06-20 00:24
 */ 

const LoginCard = next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(()=>__webpack_require__.e(/* import() */ 794).then(__webpack_require__.bind(__webpack_require__, 86794)), {
    loadableGenerated: {
        modules: [
            "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/login/page.tsx -> " + "./LoginCard"
        ]
    },
    ssr: false
});
const metadata = {
    title: "智慧商贸-登录"
};
function Login() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
        style: {
            height: "100vh",
            background: "url(/bg.svg)"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoginCard, {})
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [342,917,242,814,275,690,825,120,710], () => (__webpack_exec__(16826)));
module.exports = __webpack_exports__;

})();
(() => {
var exports = {};
exports.id = 255;
exports.ids = [255];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 31899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25980);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10119);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59692);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        '(BaseLayout)',
        {
        children: [
        'product',
        {
        children: [
        'list',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 58391)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/product/list/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 55991)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12356))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85597)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12356))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/product/list/page.tsx"];

    

    const originalPathname = "/(BaseLayout)/product/list/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/(BaseLayout)/product/list/page","pathname":"/product/list","bundlePath":"app/(BaseLayout)/product/list/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 93616:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32227));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 96879));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43926))

/***/ }),

/***/ 96879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ant_design_icons_lib_icons_DownOutlined__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(15823);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14680);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd_lib_checkbox__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(41825);
/* harmony import */ var antd_lib_col__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9833);
/* harmony import */ var antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(79519);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(51413);
/* harmony import */ var antd_lib_row__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25934);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(98087);
/* harmony import */ var antd_lib_space__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(76707);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(58882);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20189);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_MainContent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(29628);
/**
 * <p>
 * 操作栏
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-18 13:10
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 












const ActionBar = ()=>{
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const MenuItemList = [
        {
            label: "功能",
            key: "1",
            type: "group",
            children: [
                {
                    label: "移动至分类",
                    key: "1-1"
                }
            ]
        },
        {
            label: "其它",
            key: "2",
            type: "group",
            children: [
                {
                    label: "置顶",
                    key: "2-1"
                },
                {
                    label: "停用",
                    key: "2-2"
                },
                {
                    label: "启用",
                    key: "2-3"
                },
                {
                    label: "删除",
                    key: "2-4"
                }
            ]
        }
    ];
    const MoreMenuItemList = [
        {
            label: "导入",
            key: "1"
        },
        {
            label: "导出",
            key: "2"
        }
    ];
    const { token: { sizeXS } } = antd_lib_theme__WEBPACK_IMPORTED_MODULE_3__["default"].useToken();
    const SearchBox = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_input__WEBPACK_IMPORTED_MODULE_4__["default"].Search, {
            placeholder: "搜索编号、名称、规格、属性、条形码、备注",
            enterButton: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default()), {
                children: "搜索"
            })
        });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MainContent__WEBPACK_IMPORTED_MODULE_2__["default"], {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_row__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            align: "middle",
            justify: "end",
            gutter: [
                sizeXS,
                sizeXS
            ],
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    style: {
                        alignSelf: "start"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_space__WEBPACK_IMPORTED_MODULE_8__["default"], {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default()), {
                                type: "primary",
                                onClick: ()=>router.push("/product/add"),
                                children: "新增商品"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_9__["default"], {
                                menu: {
                                    items: MenuItemList
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    children: [
                                        "批量操作",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons_lib_icons_DownOutlined__WEBPACK_IMPORTED_MODULE_10__["default"], {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_9__["default"], {
                                menu: {
                                    items: MoreMenuItemList
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    children: [
                                        "更多",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons_lib_icons_DownOutlined__WEBPACK_IMPORTED_MODULE_10__["default"], {})
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    style: {
                        flexGrow: 1
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_checkbox__WEBPACK_IMPORTED_MODULE_11__["default"], {
                        checked: true,
                        children: "不显示停用商品"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_select__WEBPACK_IMPORTED_MODULE_12__["default"], {
                        style: {
                            width: 150
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    flex: "0 0 600px",
                    sm: {
                        span: 18,
                        flex: "none"
                    },
                    xl: {
                        span: 24,
                        order: 4,
                        flex: "none"
                    },
                    xxl: {
                        flex: "auto",
                        order: 3
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SearchBox, {}, "SearchBox")
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    sm: {
                        span: 6
                    },
                    xl: {
                        span: 4,
                        order: 3
                    },
                    xxl: {
                        order: 4,
                        span: 2
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default()), {
                        style: {
                            width: "100%"
                        },
                        children: "高级搜索"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActionBar);


/***/ }),

/***/ 32227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(14680);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var antd_lib_divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(25830);
/* harmony import */ var antd_lib_space__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(76707);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(98132);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_GridPro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72535);
/* harmony import */ var _components_GridPro_GridProType__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30048);
/* harmony import */ var _components_MainContent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29628);
/* harmony import */ var _ant_design_icons_lib_icons_SettingFilled__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(66464);
/**
 * <p>
 * 商品列表
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-18 13:41
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 








const TableData = [
    {
        barCode: "SP20230718000A",
        productName: "达利园蛋黄派230g",
        propertyList: "甜,蛋黄派,金黄色,原味注心",
        unitName: "袋",
        salePrice: 8.0,
        unitWeight: 0.23
    },
    {
        barCode: "001",
        productName: "美丽俏佳人专卖店",
        unitName: "对",
        salePrice: 9.9
    },
    {
        barCode: "SP20230715001A",
        productName: "创维机顶盒e900",
        unitName: "台",
        salePrice: 0.0
    },
    {
        barCode: "SP20230715000I",
        productName: "烟花",
        unitName: "对",
        salePrice: 20.0
    },
    {
        barCode: "SP20230714005I",
        productName: "福晨1.9-2",
        unitName: "对",
        salePrice: 0.0
    },
    {
        barCode: "SP20230714004I",
        productName: "福晨1.7-1.8",
        unitName: "斤",
        salePrice: 0.0
    },
    {
        barCode: "SP20230714003",
        productName: "普利司通205/55R17 EP150 91V",
        unitName: "条",
        salePrice: 0.0
    },
    {
        barCode: "SP20230714002",
        productName: "米其林205/65R16 95H XM2+",
        unitName: "条",
        salePrice: 0.0
    },
    {
        barCode: "Desert001",
        productName: "Desert螺蛳粉",
        propertyList: "特辣",
        unitName: "对",
        salePrice: 10.0,
        unitWeight: 1
    },
    {
        barCode: "SP20230713010I",
        productName: "尖椒",
        unitName: "斤",
        salePrice: 0.0
    }
];
const ButtonStyle = {
    padding: 0,
    height: "auto"
};
const ProductGrid = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_MainContent__WEBPACK_IMPORTED_MODULE_4__["default"], {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_GridPro__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            data: TableData,
            height: 300,
            columns: [
                {
                    width: 50,
                    title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons_lib_icons_SettingFilled__WEBPACK_IMPORTED_MODULE_5__["default"], {}),
                    align: _components_GridPro_GridProType__WEBPACK_IMPORTED_MODULE_3__/* .GridProAlignType */ .QY.Center,
                    key: "setting",
                    render: (value, record, index)=>index + 1,
                    fixed: _components_GridPro_GridProType__WEBPACK_IMPORTED_MODULE_3__/* .GridProFixedType */ .mj.Left
                },
                {
                    title: "操作",
                    key: "action",
                    width: 100,
                    align: _components_GridPro_GridProType__WEBPACK_IMPORTED_MODULE_3__/* .GridProAlignType */ .QY.Center,
                    fixed: _components_GridPro_GridProType__WEBPACK_IMPORTED_MODULE_3__/* .GridProFixedType */ .mj.Left,
                    render: (value, record, index)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_space__WEBPACK_IMPORTED_MODULE_6__["default"], {
                            size: 0,
                            split: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_divider__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                type: "vertical"
                            }),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "",
                                    children: "详情"
                                }, "Detail"),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_8___default()), {
                                    type: "link",
                                    style: ButtonStyle,
                                    children: "复制"
                                }, "Copy"),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_8___default()), {
                                    type: "link",
                                    style: ButtonStyle,
                                    children: "编辑"
                                }, "Edit"),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_button__WEBPACK_IMPORTED_MODULE_8___default()), {
                                    type: "link",
                                    style: ButtonStyle,
                                    children: [
                                        "删除",
                                        " "
                                    ]
                                }, "Remove")
                            ]
                        });
                    }
                },
                {
                    title: "编号",
                    field: "barCode",
                    key: "barCode",
                    width: 150,
                    fixed: _components_GridPro_GridProType__WEBPACK_IMPORTED_MODULE_3__/* .GridProFixedType */ .mj.Left
                },
                {
                    title: "名称",
                    field: "productName",
                    key: "productName",
                    width: 200,
                    fixed: _components_GridPro_GridProType__WEBPACK_IMPORTED_MODULE_3__/* .GridProFixedType */ .mj.Left
                },
                {
                    title: "属性",
                    key: "attr",
                    field: "propertyList",
                    width: 150
                },
                {
                    title: "基本单位",
                    field: "unitName",
                    key: "unitName",
                    width: 90
                },
                {
                    title: "零售价(元)",
                    field: "salePrice",
                    key: "salePrice",
                    width: 90
                },
                {
                    title: "单位重量(kg)",
                    field: "unitWeight",
                    key: "unitWeight",
                    minWidth: 90
                }
            ],
            rowKey: (d)=>d.barCode,
            rowSelection: {
                type: "checkbox"
            }
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductGrid);


/***/ }),

/***/ 58391:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+next@13.4.12_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(44266);
;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/list/ActionBar.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/product/list/ActionBar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const ActionBar = (__default__);
;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/list/ProductGrid.tsx

const ProductGrid_proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/product/list/ProductGrid.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: ProductGrid_esModule, $$typeof: ProductGrid_$$typeof } = ProductGrid_proxy;
const ProductGrid_default_ = ProductGrid_proxy.default;


/* harmony default export */ const ProductGrid = (ProductGrid_default_);
// EXTERNAL MODULE: ./src/components/LayoutSpace.tsx
var LayoutSpace = __webpack_require__(7310);
;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/list/page.tsx
/**
 * <p>
 * 商品
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-18 13:04
 */ 



const metadata = {
    title: "商品-智慧商城",
    description: "Generated by create next app"
};
const ProductList = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ActionBar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(LayoutSpace/* default */.ZP, {
                direction: "vertical"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ProductGrid, {})
        ]
    });
};
/* harmony default export */ const page = (ProductList);


/***/ }),

/***/ 7310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44266);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/components/LayoutSpace.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 20189:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(92009)


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [342,917,875,242,814,275,27,494,825,359,710,976,535], () => (__webpack_exec__(31899)));
module.exports = __webpack_exports__;

})();
(() => {
var exports = {};
exports.id = 549;
exports.ids = [549];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 10757:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25980);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10119);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59692);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        '(BaseLayout)',
        {
        children: [
        'product',
        {
        children: [
        'add',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 35240)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/product/add/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 55991)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12356))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85597)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12356))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/product/add/page.tsx"];

    

    const originalPathname = "/(BaseLayout)/product/add/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/(BaseLayout)/product/add/page","pathname":"/product/add","bundlePath":"app/(BaseLayout)/product/add/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 7762:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68100))

/***/ }),

/***/ 68100:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/components/MainContent.tsx
var MainContent = __webpack_require__(29628);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/button/index.js
var lib_button = __webpack_require__(14680);
var button_default = /*#__PURE__*/__webpack_require__.n(lib_button);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/checkbox/index.js
var lib_checkbox = __webpack_require__(41825);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/col/index.js
var col = __webpack_require__(9833);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/form/index.js
var lib_form = __webpack_require__(51690);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/input/index.js
var input = __webpack_require__(51413);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/row/index.js
var row = __webpack_require__(25934);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/select/index.js
var lib_select = __webpack_require__(98087);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/switch/index.js
var lib_switch = __webpack_require__(99655);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/theme/index.js
var theme = __webpack_require__(58882);
;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/add/components/form/BaseInfoForm.tsx
/**
 * <p>
 * 基础数据表单
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-19 16:59
 */ /* __next_internal_client_entry_do_not_use__ BaseInfoForm auto */ 









const BaseInfoForm = (props)=>{
    const { token: { margin } } = theme["default"].useToken();
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z, {
            labelCol: {
                span: 8
            },
            form: props.form,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(row/* default */.Z, {
                gutter: margin,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 8,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "条形码",
                            name: "billNo",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                suffix: /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                                    type: "link",
                                    style: {
                                        padding: 0,
                                        height: "auto"
                                    },
                                    children: "生成"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 8,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "商品编号",
                            name: "productNo",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 16,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "名称",
                            labelCol: {
                                span: 4
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                placeholder: "例如: NFC芒果汁"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 8
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 8,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "商品分类",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(lib_select["default"], {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 8,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "单位",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 8,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(lib_checkbox["default"], {
                                children: "启用多单位"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 8,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "启用商品",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(lib_switch/* default */.Z, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 16
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 8,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "单位重量(kg)",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                addonAfter: "kg",
                                placeholder: "基本单位的重量"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 16
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 16,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "备注",
                            labelCol: {
                                span: 4
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"].TextArea, {
                                rows: 2
                            })
                        })
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./src/components/LayoutSpace.tsx
var LayoutSpace = __webpack_require__(43926);
;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/add/components/form/PriceForm.tsx
/**
 * <p>
 * 价格表单
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-19 17:28
 */ /* __next_internal_client_entry_do_not_use__ PriceForm auto */ 





const PriceForm = (props)=>{
    const { token: { margin } } = theme["default"].useToken();
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z, {
            layout: "vertical",
            form: props.form,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(row/* default */.Z, {
                gutter: margin,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "零售价",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                addonAfter: "元",
                                placeholder: "请输入"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "批发价",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                addonAfter: "元",
                                placeholder: "请输入"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "等级价一",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                addonAfter: "元",
                                placeholder: "批发价 x 100%"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "等级价二",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                addonAfter: "元",
                                placeholder: "批发价 x 100%"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "等级价三",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                addonAfter: "元",
                                placeholder: "批发价 x 100%"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "最低售价",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                addonAfter: "元",
                                placeholder: "请输入"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                        span: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                            label: "参考进货价",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {
                                addonAfter: "元",
                                placeholder: "请输入"
                            })
                        })
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./src/components/GridPro/index.tsx
var GridPro = __webpack_require__(72535);
;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/add/components/form/InventoryForm.tsx
/**
 * <p>
 * 库存录入
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-19 17:38
 */ 

const InventoryForm = ()=>{
    const Columns = [
        {
            title: "仓库"
        },
        {
            title: "期初库存数量"
        },
        {
            title: "期初成本价"
        },
        {
            title: "期初总金额"
        },
        {
            title: "备注"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(GridPro/* default */.Z, {
            columns: Columns
        })
    });
};

;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/add/components/form/InventoryAlertForm.tsx
/**
 * <p>
 * 库存预警
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-19 17:44
 */ /* __next_internal_client_entry_do_not_use__ InventoryAlertForm auto */ 


const InventoryAlertForm = ()=>{
    const Columns = [
        {
            title: "仓库"
        },
        {
            title: "最低库存数量"
        },
        {
            title: "最高库存数量"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(GridPro/* default */.Z, {
                columns: Columns
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/space/index.js
var space = __webpack_require__(76707);
;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/add/components/FooterAction.tsx
/**
 * <p>
 * a1
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-19 17:54
 */ /* __next_internal_client_entry_do_not_use__ FooterAction auto */ 




const FooterAction = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(row/* default */.Z, {
            justify: "space-between",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(col/* default */.Z, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(space["default"], {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                                children: "取消"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                                children: "保存"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                                children: "保存并复制新增"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                                type: "primary",
                                onClick: props.saveAndAdd,
                                children: "保存并新增"
                            })
                        ]
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/app/(BaseLayout)/product/add/page.tsx
/**
 * <p>
 * 添加商品
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-19 16:54
 */ /* __next_internal_client_entry_do_not_use__ default auto */ 








const ProductAddPage = ()=>{
    const [form] = lib_form/* default */.Z.useForm();
    const saveAndAdd = ()=>{
        console.log(form.getFieldsValue());
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(MainContent["default"], {
                title: "基本信息",
                children: /*#__PURE__*/ jsx_runtime_.jsx(BaseInfoForm, {
                    form: form
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(LayoutSpace["default"], {
                direction: "vertical"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MainContent["default"], {
                title: "价格管理",
                children: /*#__PURE__*/ jsx_runtime_.jsx(PriceForm, {
                    form: form
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(LayoutSpace["default"], {
                direction: "vertical"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MainContent["default"], {
                title: "期初库存",
                children: /*#__PURE__*/ jsx_runtime_.jsx(InventoryForm, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(LayoutSpace["default"], {
                direction: "vertical"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MainContent["default"], {
                title: "库存预警",
                children: /*#__PURE__*/ jsx_runtime_.jsx(InventoryAlertForm, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(LayoutSpace["default"], {
                direction: "vertical"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MainContent["default"], {
                style: {
                    position: "sticky",
                    bottom: 0
                },
                size: "small",
                children: /*#__PURE__*/ jsx_runtime_.jsx(FooterAction, {
                    saveAndAdd: saveAndAdd
                })
            })
        ]
    });
};
/* harmony default export */ const page = (ProductAddPage);


/***/ }),

/***/ 35240:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44266);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/product/add/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [342,917,875,242,814,275,27,690,494,825,359,655,710,976,535], () => (__webpack_exec__(10757)));
module.exports = __webpack_exports__;

})();
(() => {
var exports = {};
exports.id = 144;
exports.ids = [144];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 36615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25980);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10119);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59692);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        '(BaseLayout)',
        {
        children: [
        'unit',
        {
        children: [
        'list',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 96971)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/unit/list/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 55991)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12356))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85597)), "/Users/clover/dev-project/zhsm/zhsm-ui/src/app/layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12356))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/unit/list/page.tsx"];

    

    const originalPathname = "/(BaseLayout)/unit/list/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/(BaseLayout)/unit/list/page","pathname":"/unit/list","bundlePath":"app/(BaseLayout)/unit/list/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 35151:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82475));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 74306));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 29628))

/***/ }),

/***/ 82475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActionBar: () => (/* binding */ ActionBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(14680);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd_lib_col__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9833);
/* harmony import */ var antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(79519);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(51413);
/* harmony import */ var antd_lib_row__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25934);
/* harmony import */ var antd_lib_space__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76707);
/* harmony import */ var antd_lib_theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(58882);
/* harmony import */ var _ant_design_icons_lib_icons_DownOutlined__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(15823);
/**
 * <p>
 * 操作栏
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-20 13:33
 */ /* __next_internal_client_entry_do_not_use__ ActionBar auto */ 








const ActionBar = ()=>{
    const { token: { margin } } = antd_lib_theme__WEBPACK_IMPORTED_MODULE_1__["default"].useToken();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_row__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            justify: "space-between",
            gutter: [
                margin,
                margin
            ],
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd_lib_space__WEBPACK_IMPORTED_MODULE_4__["default"], {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default()), {
                                type: "primary",
                                children: "新增单位"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                menu: {
                                    items: [
                                        {
                                            label: "删除",
                                            key: "Delete"
                                        },
                                        {
                                            label: "启用",
                                            key: "Enable"
                                        },
                                        {
                                            label: "停用",
                                            key: "Disable"
                                        }
                                    ]
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    children: [
                                        "批量操作",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons_lib_icons_DownOutlined__WEBPACK_IMPORTED_MODULE_7__["default"], {})
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_col__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    flex: "0 0 300px",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd_lib_input__WEBPACK_IMPORTED_MODULE_8__["default"].Search, {
                        enterButton: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_5___default()), {
                            children: "搜索"
                        })
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 74306:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AddUnitDrawer: () => (/* binding */ AddUnitDrawer)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/button/index.js
var lib_button = __webpack_require__(14680);
var button_default = /*#__PURE__*/__webpack_require__.n(lib_button);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/form/index.js
var lib_form = __webpack_require__(51690);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/input/index.js
var input = __webpack_require__(51413);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/radio/index.js
var lib_radio = __webpack_require__(15772);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/space/index.js
var space = __webpack_require__(76707);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/drawer/index.js
var drawer = __webpack_require__(99306);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+antd@5.7.2_react-dom@18.2.0_react@18.2.0/node_modules/antd/lib/theme/index.js
var theme = __webpack_require__(58882);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./src/components/DrawerPro/index.tsx
/**
 * <p>
 * Drawer 组件封装
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-20 13:45
 */ 



const DrawerPro = (props)=>{
    const { token: { screenXSMax, size } } = theme["default"].useToken();
    const id = (0,react_.useId)();
    const [placement, setPlacement] = (0,react_.useState)("right");
    const customPlacement = (0,react_.useRef)(false);
    const resize = (0,react_.useCallback)(()=>{
        const minWidth = window.innerWidth - size;
        if (minWidth >= screenXSMax) {
            if (placement !== "right") {
                setPlacement("right");
            }
            if (props.width != void 0) {
                const dom = document.querySelector(`[data-id="${id}"]`);
                if (dom != void 0) {
                    if (props.width >= minWidth) {
                        dom.style.width = minWidth + "px";
                    } else {
                        dom.style.width = (props.width + "px") ?? "378px";
                    }
                }
            }
            return;
        }
        if (placement !== "bottom") setPlacement("bottom");
        const dom = document.querySelector(`[data-id="${id}"]`);
        if (dom == void 0) return;
        dom.style.width = innerWidth + "px";
    }, [
        id,
        placement,
        props.width,
        screenXSMax,
        size
    ]);
    (0,react_.useEffect)(()=>{
        setTimeout(resize);
        window.addEventListener("resize", resize);
        return ()=>{
            window.removeEventListener("resize", resize);
        };
    }, [
        resize,
        placement
    ]);
    (0,react_.useEffect)(()=>{
        if (props.placement == void 0) return;
        setPlacement(props.placement);
        customPlacement.current = true;
    }, [
        props.placement,
        props
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(drawer/* default */.Z, {
        ...props,
        width: props.width,
        placement: placement,
        "data-id": id
    });
};
/* harmony default export */ const components_DrawerPro = (/*#__PURE__*/(0,react_.memo)(DrawerPro));

;// CONCATENATED MODULE: ./src/app/(BaseLayout)/unit/list/components/AddUnitDrawer.tsx
/**
 * <p>
 * 新增单位抽屉
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-20 13:41
 */ /* __next_internal_client_entry_do_not_use__ AddUnitDrawer auto */ 







const AddUnitDrawer = ()=>{
    const FooterAction = (0,react_.useCallback)(()=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(space["default"], {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                    children: "保存并新增"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                    type: "primary",
                    children: "保存"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((button_default()), {
                    children: "取消"
                })
            ]
        });
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(components_DrawerPro, {
        title: "新增单位",
        width: 700,
        open: true,
        footer: /*#__PURE__*/ jsx_runtime_.jsx(FooterAction, {}),
        height: 700,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib_form/* default */.Z, {
            layout: "vertical",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                    label: "单位名称",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"], {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(space["default"], {
                        size: 16,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "允许小数"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib_radio["default"].Group, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(lib_radio["default"], {
                                        children: "允许"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(lib_radio["default"], {
                                        children: "不允许"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib_form/* default */.Z.Item, {
                    label: "备注",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(input["default"].TextArea, {
                        rows: 3
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 96971:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/components/MainContent.tsx
var MainContent = __webpack_require__(47353);
// EXTERNAL MODULE: ./node_modules/.pnpm/registry.npmmirror.com+next@13.4.12_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(44266);
;// CONCATENATED MODULE: ./src/app/(BaseLayout)/unit/list/components/ActionBar.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/unit/list/components/ActionBar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["ActionBar"];

;// CONCATENATED MODULE: ./src/app/(BaseLayout)/unit/list/components/AddUnitDrawer.tsx

const AddUnitDrawer_proxy = (0,module_proxy.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/app/(BaseLayout)/unit/list/components/AddUnitDrawer.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: AddUnitDrawer_esModule, $$typeof: AddUnitDrawer_$$typeof } = AddUnitDrawer_proxy;
const AddUnitDrawer_default_ = AddUnitDrawer_proxy.default;

const AddUnitDrawer_e0 = AddUnitDrawer_proxy["AddUnitDrawer"];

;// CONCATENATED MODULE: ./src/app/(BaseLayout)/unit/list/page.tsx
/**
 * <p>
 * a1
 * </p>
 *
 * @version: v1.0
 * @author: Clover
 * @create: 2023-07-20 13:27
 */ 



const metadata = {
    title: "单位-智慧商城"
};
const UnitList = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(AddUnitDrawer_e0, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(MainContent/* default */.ZP, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(e0, {})
            })
        ]
    });
};
/* harmony default export */ const page = (UnitList);


/***/ }),

/***/ 47353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44266);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/clover/dev-project/zhsm/zhsm-ui/src/components/MainContent.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [342,917,875,242,814,690,494,306,710,976], () => (__webpack_exec__(36615)));
module.exports = __webpack_exports__;

})();